export enum GameTheme {
  VICTORIAN = 'VICTORIAN',
  JUNGLE = 'JUNGLE',
  SPACE = 'SPACE'
}

export enum PuzzleType {
  RIDDLE = 'RIDDLE',
  CODE = 'CODE',
  COMBINATION = 'COMBINATION'
}

export interface Item {
  id: string;
  name: string;
  description: string;
  icon: string; // Emoji or simple text representation
}

export interface Puzzle {
  id: string;
  type: PuzzleType;
  question: string;
  solution: string; // Used for basic client-side validation, AI can override
  isSolved: boolean;
  hint: string; // Static hint, AI generates dynamic ones
  rewardItemId?: string; // Item given upon completion
  unlocksRoomId?: string; // Room unlocked upon completion
}

export interface Room {
  id: string;
  name: string;
  description: string;
  imageUrl: string;
  interactables: Interactable[];
  puzzles: Puzzle[];
  exits: string[]; // IDs of connected rooms
}

export interface Interactable {
  id: string;
  name: string;
  description: string;
  requiredItemId?: string; // Need this item to interact
  givesItemId?: string; // Gives this item when interacted
  isLocked: boolean;
  message: string; // Flavour text
}

export interface LevelData {
  id: string;
  theme: GameTheme;
  title: string;
  introduction: string;
  rooms: Room[];
  startingRoomId: string;
}

export interface ChatMessage {
  role: 'user' | 'model' | 'system';
  text: string;
  timestamp: number;
}

export interface GameState {
  currentLevelId: string;
  currentRoomId: string;
  inventory: Item[];
  solvedPuzzleIds: string[];
  unlockedRoomIds: string[];
  chatHistory: ChatMessage[];
  isLoading: boolean;
  gameStarted: boolean;
}

export type GameAction =
  | { type: 'START_GAME'; levelId: string }
  | { type: 'MOVE_ROOM'; roomId: string }
  | { type: 'PICKUP_ITEM'; item: Item }
  | { type: 'USE_ITEM'; itemId: string }
  | { type: 'SOLVE_PUZZLE'; puzzleId: string }
  | { type: 'ADD_MESSAGE'; message: ChatMessage }
  | { type: 'SET_LOADING'; isLoading: boolean }
  | { type: 'RESET_GAME' };
