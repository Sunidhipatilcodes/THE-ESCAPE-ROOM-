import React, { createContext, useContext, useReducer, ReactNode } from 'react';
import { GameState, GameAction, ChatMessage, Item } from '../types';

const initialState: GameState = {
  currentLevelId: '',
  currentRoomId: '',
  inventory: [],
  solvedPuzzleIds: [],
  unlockedRoomIds: [],
  chatHistory: [{
    role: 'model',
    text: 'Welcome, Traveler. Select a simulation to begin.',
    timestamp: Date.now()
  }],
  isLoading: false,
  gameStarted: false
};

const gameReducer = (state: GameState, action: GameAction): GameState => {
  switch (action.type) {
    case 'START_GAME':
      return {
        ...state,
        gameStarted: true,
        currentLevelId: action.levelId,
        inventory: [],
        solvedPuzzleIds: [],
        unlockedRoomIds: [],
        chatHistory: [{
          role: 'model',
          text: 'Initializing environment... The air shifts around you.',
          timestamp: Date.now()
        }]
      };
    case 'MOVE_ROOM':
      return { ...state, currentRoomId: action.roomId };
    case 'PICKUP_ITEM':
      return { ...state, inventory: [...state.inventory, action.item] };
    case 'SOLVE_PUZZLE':
      return { ...state, solvedPuzzleIds: [...state.solvedPuzzleIds, action.puzzleId] };
    case 'ADD_MESSAGE':
      return { ...state, chatHistory: [...state.chatHistory, action.message] };
    case 'SET_LOADING':
      return { ...state, isLoading: action.isLoading };
    case 'RESET_GAME':
      return initialState;
    default:
      return state;
  }
};

interface GameContextProps {
  state: GameState;
  dispatch: React.Dispatch<GameAction>;
}

const GameContext = createContext<GameContextProps | undefined>(undefined);

export const GameProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(gameReducer, initialState);

  return (
    <GameContext.Provider value={{ state, dispatch }}>
      {children}
    </GameContext.Provider>
  );
};

export const useGame = () => {
  const context = useContext(GameContext);
  if (!context) {
    throw new Error('useGame must be used within a GameProvider');
  }
  return context;
};