import { GameTheme, Item, LevelData, PuzzleType } from "./types";

export const ITEMS: Record<string, Item> = {
  OLD_KEY: { id: 'OLD_KEY', name: 'Rusted Key', description: 'An old iron key with a gothic design.', icon: '🗝️' },
  FLASHLIGHT: { id: 'FLASHLIGHT', name: 'UV Flashlight', description: 'Reveals hidden markings.', icon: '🔦' },
  GEMSTONE: { id: 'GEMSTONE', name: 'Ruby Eye', description: 'A red gemstone taken from a statue.', icon: '💎' },
  ACCESS_CARD: { id: 'ACCESS_CARD', name: 'Level 5 Keycard', description: 'Standard issue clearance card.', icon: '💳' },
  CROWBAR: { id: 'CROWBAR', name: 'Crowbar', description: 'Heavy steel tool.', icon: '🔧' }
};

export const LEVELS: LevelData[] = [
  {
    id: 'level-1',
    theme: GameTheme.VICTORIAN,
    title: 'The Haunting of Blackwood Manor',
    introduction: 'You wake up in a cold, dimly lit foyer. The door behind you is sealed shut. A voice whispers from the shadows...',
    startingRoomId: 'room-foyer',
    rooms: [
      {
        id: 'room-foyer',
        name: 'Grand Foyer',
        description: 'Dust motes dance in the sliver of moonlight. A grand staircase leads up, but it is blocked by debris. To your left, a heavy oak door.',
        imageUrl: 'https://picsum.photos/800/600?grayscale&blur=2',
        interactables: [
          {
            id: 'coat-rack',
            name: 'Old Coat Rack',
            description: 'A moth-eaten coat hangs here.',
            isLocked: false,
            message: 'You search the pockets...',
            givesItemId: 'OLD_KEY'
          }
        ],
        puzzles: [],
        exits: ['room-library']
      },
      {
        id: 'room-library',
        name: 'The Forgotten Library',
        description: 'Bookshelves tower over you. A strange painting hangs above the fireplace.',
        imageUrl: 'https://picsum.photos/800/601?sepia',
        interactables: [
           {
            id: 'painting',
            name: 'Portrait of Lord Blackwood',
            description: 'His eyes seem to follow you. There is a keyhole in the frame.',
            isLocked: true,
            requiredItemId: 'OLD_KEY',
            message: 'The frame clicks open, revealing a safe!',
          }
        ],
        puzzles: [
          {
            id: 'safe-puzzle',
            type: PuzzleType.CODE,
            question: 'The safe requires a 4-digit combination. Etched on the wall: "The year the house burned down."',
            hint: 'Look for a date on the portrait plaque.',
            solution: '1894',
            isSolved: false,
            rewardItemId: 'FLASHLIGHT',
            unlocksRoomId: 'room-attic'
          }
        ],
        exits: ['room-foyer', 'room-attic']
      },
       {
        id: 'room-attic',
        name: 'The Attic',
        description: 'Dark, cramped, and full of whispers. A final door stands before you.',
        imageUrl: 'https://picsum.photos/800/602?grayscale',
        interactables: [],
        puzzles: [
           {
            id: 'final-riddle',
            type: PuzzleType.RIDDLE,
            question: 'I have cities, but no houses. I have mountains, but no trees. I have water, but no fish. What am I?',
            hint: 'You use it to find your way.',
            solution: 'map',
            isSolved: false,
          }
        ],
        exits: ['room-library']
      }
    ]
  },
  {
    id: 'level-2',
    theme: GameTheme.JUNGLE,
    title: 'Temple of the Sun',
    introduction: 'The helicopter dropped you off miles away. Vines choke the entrance to the ancient stone structure.',
    startingRoomId: 'jungle-entrance',
    rooms: [
      {
        id: 'jungle-entrance',
        name: 'Temple Entrance',
        description: 'Stone faces glare at you. The path is blocked by thick roots.',
        imageUrl: 'https://picsum.photos/800/600?blur=1',
        interactables: [
           {
            id: 'roots',
            name: 'Thick Vines',
            description: 'They are too thick to break by hand.',
            isLocked: true,
            requiredItemId: 'CROWBAR', // Intentionally using a weird item for demo
            message: 'You pry the roots apart.',
           },
           {
             id: 'crate',
             name: 'Supply Crate',
             description: 'Left by a previous expedition.',
             isLocked: false,
             message: 'You found a crowbar!',
             givesItemId: 'CROWBAR'
           }
        ],
        puzzles: [],
        exits: ['jungle-altar']
      },
      {
        id: 'jungle-altar',
        name: 'Sun Altar',
        description: 'A shaft of light illuminates a pedestal with a missing eye.',
        imageUrl: 'https://picsum.photos/800/601',
        interactables: [],
        puzzles: [
           {
            id: 'statue-puzzle',
            type: PuzzleType.RIDDLE,
            question: 'The more of this there is, the less you see. What is it?',
            hint: 'It comes at night.',
            solution: 'darkness',
            isSolved: false,
            rewardItemId: 'GEMSTONE'
          }
        ],
        exits: ['jungle-entrance']
      }
    ]
  },
  {
    id: 'level-3',
    theme: GameTheme.SPACE,
    title: 'Station Zeta-9',
    introduction: 'Oxygen levels critical. You must restore power to the escape pod.',
    startingRoomId: 'airlock',
    rooms: [
      {
        id: 'airlock',
        name: 'Airlock',
        description: 'Red emergency lights flash. The door is sealed.',
        imageUrl: 'https://picsum.photos/800/600?grayscale',
        interactables: [],
        puzzles: [
           {
            id: 'terminal-hack',
            type: PuzzleType.CODE,
            question: 'Access Code Required. Sequence: 2, 4, 8, 16, ...',
            hint: 'Double it.',
            solution: '32',
            isSolved: false,
            rewardItemId: 'ACCESS_CARD',
            unlocksRoomId: 'bridge'
          }
        ],
        exits: ['bridge']
      },
       {
        id: 'bridge',
        name: 'Command Bridge',
        description: 'The view of the nebula is beautiful, but deadly. The captain\'s chair is empty.',
        imageUrl: 'https://picsum.photos/800/601?blur=2',
        interactables: [],
        puzzles: [],
        exits: ['airlock']
      }
    ]
  }
];