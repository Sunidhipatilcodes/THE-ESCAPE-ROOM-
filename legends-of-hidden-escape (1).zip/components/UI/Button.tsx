import React from 'react';
import { GameTheme } from '../../types';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'danger';
  theme?: GameTheme;
}

const Button: React.FC<ButtonProps> = ({ 
  children, 
  variant = 'primary', 
  theme = GameTheme.VICTORIAN,
  className = '',
  ...props 
}) => {
  
  let themeClasses = '';
  
  switch(theme) {
    case GameTheme.SPACE:
      themeClasses = `
        font-mono uppercase tracking-widest text-sm
        bg-cyan-950/40 border border-cyan-500/50 text-cyan-300
        hover:bg-cyan-500/20 hover:border-cyan-400 hover:shadow-[0_0_15px_rgba(6,182,212,0.4)]
        active:scale-95 transition-all duration-200
        backdrop-blur-sm
      `;
      if (variant === 'secondary') themeClasses += ' border-dashed opacity-80';
      break;
      
    case GameTheme.JUNGLE:
      themeClasses = `
        font-serif font-bold tracking-wide
        bg-stone-800/90 border-2 border-stone-600 text-amber-500
        rounded-sm
        hover:bg-stone-700 hover:border-amber-600 hover:text-amber-400
        shadow-[2px_2px_0px_rgba(0,0,0,0.5)] active:translate-y-[2px] active:shadow-none
        transition-all
      `;
      break;
      
    case GameTheme.VICTORIAN:
    default:
      themeClasses = `
        font-serif italic text-lg
        bg-slate-900 border-y-2 border-amber-700/50 text-amber-100/80
        hover:bg-slate-800 hover:text-amber-100 hover:border-amber-600
        shadow-[0_4px_10px_rgba(0,0,0,0.3)]
        transition-all duration-500 ease-in-out
      `;
      break;
  }

  const baseStyle = `px-6 py-2 relative disabled:opacity-50 disabled:cursor-not-allowed ${themeClasses} ${className}`;

  return (
    <button className={baseStyle} {...props}>
      {children}
    </button>
  );
};

export default Button;