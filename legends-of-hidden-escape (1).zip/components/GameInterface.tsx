import React, { useEffect, useRef, useState } from 'react';
import { useGame } from '../context/GameContext';
import { LEVELS, ITEMS } from '../constants';
import { GameTheme, Puzzle, Item, Room, ChatMessage } from '../types';
import Button from './UI/Button';
import PuzzleModal from './Game/PuzzleModal';
import { generateNarratorResponse } from '../services/geminiService';

const GameInterface: React.FC = () => {
  const { state, dispatch } = useGame();
  const [activePuzzle, setActivePuzzle] = useState<Puzzle | null>(null);
  const [userInput, setUserInput] = useState('');
  
  // Derived state
  const currentLevel = LEVELS.find(l => l.id === state.currentLevelId);
  const currentRoom = currentLevel?.rooms.find(r => r.id === state.currentRoomId) || currentLevel?.rooms[0];
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Initialize Room
  useEffect(() => {
    if (state.currentLevelId && !state.currentRoomId && currentLevel) {
       dispatch({ type: 'MOVE_ROOM', roomId: currentLevel.startingRoomId });
    }
  }, [state.currentLevelId, currentLevel, dispatch, state.currentRoomId]);

  // Auto-scroll chat
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [state.chatHistory]);

  if (!currentLevel || !currentRoom) return <div className="text-white">Loading Level...</div>;

  const handleInteract = (interactableId: string) => {
    const interactable = currentRoom.interactables.find(i => i.id === interactableId);
    if (!interactable) return;

    if (interactable.isLocked) {
      if (interactable.requiredItemId && state.inventory.some(i => i.id === interactable.requiredItemId)) {
        // Unlock
        dispatch({ 
            type: 'ADD_MESSAGE', 
            message: { role: 'model', text: interactable.message, timestamp: Date.now() } 
        });
        if (interactable.givesItemId) {
             const item = ITEMS[interactable.givesItemId];
             if (item) dispatch({ type: 'PICKUP_ITEM', item });
        }
      } else {
         dispatch({ 
            type: 'ADD_MESSAGE', 
            message: { role: 'model', text: `Locked. You might need ${interactable.requiredItemId ? 'an item' : 'to solve something'}.`, timestamp: Date.now() } 
        });
      }
    } else {
        dispatch({ 
            type: 'ADD_MESSAGE', 
            message: { role: 'model', text: interactable.message, timestamp: Date.now() } 
        });
        if (interactable.givesItemId && !state.inventory.find(i => i.id === interactable.givesItemId)) {
            const item = ITEMS[interactable.givesItemId];
             if (item) {
                 dispatch({ type: 'PICKUP_ITEM', item });
                 dispatch({ type: 'ADD_MESSAGE', message: {role: 'model', text: `Obtained: ${item.name}`, timestamp: Date.now()}});
             }
        }
    }
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userInput.trim() || state.isLoading) return;

    const userMsg: ChatMessage = { role: 'user', text: userInput, timestamp: Date.now() };
    dispatch({ type: 'ADD_MESSAGE', message: userMsg });
    dispatch({ type: 'SET_LOADING', isLoading: true });
    setUserInput('');

    // Call AI
    const aiText = await generateNarratorResponse(userMsg.text, state, currentLevel, currentRoom);
    
    dispatch({ 
        type: 'ADD_MESSAGE', 
        message: { role: 'model', text: aiText, timestamp: Date.now() } 
    });
    dispatch({ type: 'SET_LOADING', isLoading: false });
  };

  const handlePuzzleSolve = (puzzleId: string) => {
      dispatch({ type: 'SOLVE_PUZZLE', puzzleId });
      const puzzle = currentRoom.puzzles.find(p => p.id === puzzleId);
      
      // Handle rewards
      if (puzzle?.rewardItemId) {
          const item = ITEMS[puzzle.rewardItemId];
          if (item) {
              dispatch({ type: 'PICKUP_ITEM', item });
              dispatch({ type: 'ADD_MESSAGE', message: {role: 'model', text: `Solving the puzzle revealed: ${item.name}`, timestamp: Date.now()}});
          }
      }
      // Handle Unlocks
      if (puzzle?.unlocksRoomId) {
          dispatch({ type: 'ADD_MESSAGE', message: {role: 'model', text: `A door unlocks nearby...`, timestamp: Date.now()}});
      }
  };

  // --- THEME CONFIGURATION ---
  const themeStyles = {
    [GameTheme.VICTORIAN]: {
      main: 'bg-slate-950 font-serif',
      header: 'bg-slate-900 border-b-4 border-double border-amber-800 text-amber-100',
      panel: 'bg-slate-900/90 border-l-4 border-double border-amber-900 shadow-xl',
      chatUser: 'bg-amber-900/40 text-amber-100 border border-amber-800/30 font-serif italic',
      chatModel: 'bg-slate-800/80 text-slate-300 border border-slate-700 font-serif',
      input: 'bg-slate-950 border-amber-900/50 text-amber-100 placeholder-amber-900/30 font-serif',
      inventory: 'bg-slate-950 border-t-2 border-amber-900/50',
      accentText: 'text-amber-500',
      overlay: 'bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent',
    },
    [GameTheme.JUNGLE]: {
      main: 'bg-stone-950 font-[Cinzel]',
      header: 'bg-stone-900 border-b-2 border-stone-600 text-stone-300 tracking-widest',
      panel: 'bg-stone-900/95 border-l-8 border-stone-800',
      chatUser: 'bg-green-900/30 text-green-100 border border-green-800/30',
      chatModel: 'bg-stone-800 text-stone-300 border border-stone-700',
      input: 'bg-stone-950 border-stone-700 text-stone-200 placeholder-stone-700',
      inventory: 'bg-stone-950 border-t-4 border-stone-800',
      accentText: 'text-green-500',
      overlay: 'bg-gradient-to-t from-stone-900 via-stone-900/40 to-black/20',
    },
    [GameTheme.SPACE]: {
      main: 'bg-black font-mono crt',
      header: 'bg-black/80 border-b border-cyan-500/50 text-cyan-400 uppercase tracking-[0.2em] shadow-[0_0_10px_rgba(6,182,212,0.2)]',
      panel: 'bg-slate-950/90 border-l border-cyan-500/30 backdrop-blur-md',
      chatUser: 'bg-cyan-950/40 text-cyan-200 border border-cyan-500/30 rounded-none',
      chatModel: 'bg-slate-900/50 text-slate-300 border border-slate-700 rounded-none',
      input: 'bg-black border-cyan-900/50 text-cyan-400 placeholder-cyan-900/50 rounded-none',
      inventory: 'bg-black/80 border-t border-cyan-500/30',
      accentText: 'text-cyan-400',
      overlay: 'bg-gradient-to-t from-black via-black/50 to-transparent',
    }
  };

  const ts = themeStyles[currentLevel.theme];

  return (
    <div className={`flex flex-col h-screen w-full overflow-hidden ${ts.main} transition-colors duration-500`}>
      
      {/* HEADER */}
      <header className={`p-4 flex justify-between items-center z-20 ${ts.header}`}>
        <h1 className="text-xl md:text-2xl font-bold">
          {currentLevel.theme === GameTheme.SPACE && <span className="animate-pulse mr-2">●</span>}
          {currentLevel.title}
        </h1>
        <Button theme={currentLevel.theme} onClick={() => dispatch({ type: 'RESET_GAME' })} className="text-xs px-2 py-1" variant="secondary">
          {currentLevel.theme === GameTheme.SPACE ? 'Abort Sequence' : 'Abandon Quest'}
        </Button>
      </header>

      {/* MAIN CONTENT GRID */}
      <div className="flex-1 flex flex-col md:flex-row overflow-hidden relative">
        
        {/* LEFT: VISUAL SCENE */}
        <div className="flex-1 relative group overflow-hidden bg-black">
           {/* Background Image Layer */}
           <div 
             className="absolute inset-0 bg-cover bg-center transition-transform duration-[20s] ease-linear group-hover:scale-110 opacity-60"
             style={{ backgroundImage: `url(${currentRoom.imageUrl})` }}
           />
           {/* Overlay Gradient */}
           <div className={`absolute inset-0 ${ts.overlay}`} />

           {/* Interactive Elements Overlay */}
           <div className="absolute inset-0 p-6 md:p-12 flex flex-col justify-end pb-24 md:pb-12 z-10">
              <div className={`max-w-3xl mb-8 p-6 rounded-lg backdrop-blur-sm ${currentLevel.theme === GameTheme.VICTORIAN ? 'bg-black/40 border border-amber-900/30' : ''}`}>
                <h2 className={`text-3xl md:text-4xl font-bold mb-3 drop-shadow-lg ${ts.accentText} ${currentLevel.theme === GameTheme.VICTORIAN ? 'italic' : ''}`}>
                  {currentRoom.name}
                </h2>
                <p className="text-lg md:text-xl text-gray-200 drop-shadow-md leading-relaxed">
                  {currentRoom.description}
                </p>
              </div>
              
              <div className="flex flex-wrap gap-4 items-center">
                {/* Exits */}
                {currentRoom.exits.map(exitId => {
                    const lockingPuzzle = currentRoom.puzzles.find(p => p.unlocksRoomId === exitId);
                    const isLocked = lockingPuzzle && !state.solvedPuzzleIds.includes(lockingPuzzle.id);
                    const exitRoomName = currentLevel.rooms.find(r => r.id === exitId)?.name;

                    return (
                        <Button 
                            key={exitId} 
                            theme={currentLevel.theme} 
                            onClick={() => !isLocked && dispatch({ type: 'MOVE_ROOM', roomId: exitId })}
                            className={isLocked ? 'opacity-50 grayscale cursor-not-allowed' : 'animate-pulse hover:animate-none'}
                        >
                            {isLocked ? `Locked: ${exitRoomName}` : `Go to ${exitRoomName} ➜`}
                        </Button>
                    );
                })}

                {/* Interactables */}
                {currentRoom.interactables.map(item => (
                    <button 
                        key={item.id}
                        onClick={() => handleInteract(item.id)}
                        className={`
                          group relative px-4 py-2 rounded transition-all duration-300
                          ${currentLevel.theme === GameTheme.SPACE 
                            ? 'bg-cyan-900/20 border border-cyan-500/30 text-cyan-200 hover:bg-cyan-500/20' 
                            : currentLevel.theme === GameTheme.JUNGLE
                            ? 'bg-stone-800/60 border-2 border-stone-600 text-stone-200 hover:border-amber-500'
                            : 'bg-slate-900/60 border border-amber-700/50 text-amber-100 hover:bg-amber-900/40'
                          }
                        `}
                    >
                        <span className="mr-2 text-xl inline-block group-hover:rotate-12 transition-transform">🔍</span> 
                        {item.name}
                    </button>
                ))}

                {/* Puzzles */}
                {currentRoom.puzzles.map(puzzle => {
                    if (state.solvedPuzzleIds.includes(puzzle.id)) return null;
                    return (
                        <button
                             key={puzzle.id}
                             onClick={() => setActivePuzzle(puzzle)}
                             className={`
                               px-5 py-3 rounded font-bold shadow-lg animate-bounce hover:animate-none transition-all
                               ${currentLevel.theme === GameTheme.SPACE
                                 ? 'bg-yellow-500/20 text-yellow-300 border border-yellow-400/50 hover:bg-yellow-500/30'
                                 : 'bg-gradient-to-r from-amber-600 to-amber-700 text-white border border-amber-400'
                               }
                             `}
                        >
                             🧩 {puzzle.type === 'CODE' ? 'Unlock Device' : 'Inspect Puzzle'}
                        </button>
                    )
                })}
              </div>
           </div>
        </div>

        {/* RIGHT: CHAT & INVENTORY */}
        <div className={`w-full md:w-[400px] flex flex-col z-20 ${ts.panel}`}>
          
          {/* Chat History */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-hide">
             {state.chatHistory.map((msg, idx) => (
               <div key={idx} className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
                 <div className={`max-w-[85%] p-3 rounded-lg text-sm shadow-md ${msg.role === 'user' ? ts.chatUser : ts.chatModel}`}>
                   {msg.text}
                 </div>
                 <span className={`text-[10px] opacity-40 mt-1 uppercase tracking-wider ${ts.accentText}`}>
                   {msg.role === 'model' ? 'Game Master' : 'You'}
                 </span>
               </div>
             ))}
             {state.isLoading && <div className={`text-xs animate-pulse opacity-50 ml-2 ${ts.accentText}`}>Analyzing input stream...</div>}
             <div ref={chatEndRef} />
          </div>

          {/* Input Area */}
          <form onSubmit={handleSendMessage} className={`p-4 border-t ${currentLevel.theme === GameTheme.SPACE ? 'border-cyan-500/20' : 'border-white/5'} bg-black/10`}>
             <div className="flex gap-2 relative">
               <input 
                 className={`flex-1 outline-none text-sm px-4 py-3 rounded shadow-inner ${ts.input}`}
                 placeholder={currentLevel.theme === GameTheme.SPACE ? "Type command..." : "What do you want to do?"}
                 value={userInput}
                 onChange={(e) => setUserInput(e.target.value)}
                 disabled={state.isLoading}
                 autoFocus
               />
               <button 
                 type="submit" 
                 disabled={state.isLoading} 
                 className={`px-4 transition-transform hover:scale-105 ${ts.accentText} disabled:opacity-30`}
               >
                 ➤
               </button>
             </div>
          </form>

          {/* Inventory Strip */}
          <div className={`p-4 ${ts.inventory}`}>
             <h3 className={`text-xs uppercase tracking-widest opacity-50 mb-3 ${ts.accentText}`}>Inventory</h3>
             <div className="flex gap-3 min-h-[60px] flex-wrap">
                {state.inventory.length === 0 && <span className="text-xs italic opacity-30 self-center">No items collected.</span>}
                {state.inventory.map(item => (
                  <div 
                    key={item.id} 
                    className={`
                      w-14 h-14 rounded flex items-center justify-center text-2xl cursor-help group relative transition-all hover:scale-110
                      ${currentLevel.theme === GameTheme.SPACE ? 'bg-cyan-900/30 border border-cyan-500/50' : 'bg-white/5 border border-white/10'}
                    `}
                  >
                     {item.icon}
                     {/* Tooltip */}
                     <div className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2 w-40 hidden group-hover:block bg-black/90 text-white text-xs p-2 rounded z-50 pointer-events-none border border-white/20 shadow-xl">
                       <strong className="block mb-1 text-amber-400">{item.name}</strong>
                       {item.description}
                     </div>
                  </div>
                ))}
             </div>
          </div>

        </div>
      </div>

      {/* PUZZLE MODAL */}
      {activePuzzle && (
        <PuzzleModal 
          puzzle={activePuzzle} 
          theme={currentLevel.theme}
          onClose={() => setActivePuzzle(null)} 
          onSolve={() => handlePuzzleSolve(activePuzzle.id)} 
        />
      )}
    </div>
  );
};

export default GameInterface;