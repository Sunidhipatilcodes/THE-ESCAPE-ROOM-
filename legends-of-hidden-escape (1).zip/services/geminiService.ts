import { GoogleGenAI, Type } from "@google/genai";
import { GameState, LevelData, Room } from "../types";

// Initialize Gemini
// NOTE: In a real production app, ensure API_KEY is strictly handled.
// Using process.env.API_KEY as per instructions.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateNarratorResponse = async (
  prompt: string,
  gameState: GameState,
  currentLevel: LevelData,
  currentRoom: Room
): Promise<string> => {
  
  const systemInstruction = `
    You are the "AI Game Master" for an Escape Room game. 
    Current Theme: ${currentLevel.theme}.
    Current Room: ${currentRoom.name} - ${currentRoom.description}.
    
    Your goal is to be immersive, atmospheric, and helpful but cryptic.
    Never break character.
    If the user asks for a hint, give a subtle clue based on the room's puzzles, do not give the direct answer.
    If the user performs an action, describe the result vividly.
    Keep responses concise (under 50 words) unless describing a major event.
    The user's inventory contains: ${gameState.inventory.map(i => i.name).join(', ') || 'Nothing'}.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.7, // Slightly creative
        // maxOutputTokens removed to avoid cutting off responses or conflicting with thinking budget defaults
      }
    });

    return response.text || "The connection to the AI core is static... try again.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "A glitch in the simulation prevents a response.";
  }
};

export const validatePuzzleWithAI = async (
  puzzleQuestion: string,
  userAnswer: string
): Promise<{ isCorrect: boolean; feedback: string }> => {
  
  const prompt = `
    Riddle/Puzzle: "${puzzleQuestion}"
    User Answer: "${userAnswer}"
    
    Is this answer correct? It might be a variation or synonym.
    The feedback should be in the voice of a Game Master (encouraging or mocking slightly).
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            isCorrect: { type: Type.BOOLEAN },
            feedback: { type: Type.STRING },
          },
          required: ["isCorrect", "feedback"],
        },
      }
    });
    
    const text = response.text;
    if (!text) throw new Error("No response");
    
    return JSON.parse(text);
  } catch (error) {
    console.error("Gemini Validation Error:", error);
    // Fallback to strict equality if AI fails
    return { isCorrect: false, feedback: "I couldn't verify that thought. Try being more precise." };
  }
};