import React, { useState } from 'react';
import { Puzzle, GameTheme } from '../../types';
import Button from '../UI/Button';
import { validatePuzzleWithAI } from '../../services/geminiService';
import { useGame } from '../../context/GameContext';

interface PuzzleModalProps {
  puzzle: Puzzle;
  theme: GameTheme;
  onClose: () => void;
  onSolve: () => void;
}

const PuzzleModal: React.FC<PuzzleModalProps> = ({ puzzle, theme, onClose, onSolve }) => {
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);
  const { dispatch } = useGame();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setFeedback("Processing...");

    // Check strict solution first for speed
    if (input.toLowerCase().trim() === puzzle.solution.toLowerCase()) {
      setFeedback("Solution Verified.");
      setTimeout(() => {
        onSolve();
        onClose();
      }, 1000);
      setLoading(false);
      return;
    }

    // AI Fallback for fuzzy matching
    const aiResult = await validatePuzzleWithAI(puzzle.question, input);
    
    setFeedback(aiResult.feedback);
    
    if (aiResult.isCorrect) {
       setTimeout(() => {
        onSolve();
        onClose();
      }, 2000);
    }
    
    setLoading(false);
  };

  // Theme-specific container styles
  const getThemeStyles = () => {
    switch(theme) {
      case GameTheme.SPACE:
        return {
          container: 'bg-black/90 border-2 border-cyan-500 shadow-[0_0_50px_rgba(6,182,212,0.3)] font-mono',
          title: 'text-cyan-400 uppercase tracking-widest border-b border-cyan-900 pb-2',
          text: 'text-cyan-100',
          input: 'bg-black border border-cyan-700 text-cyan-400 focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 placeholder-cyan-900',
          overlay: 'backdrop-blur-md bg-cyan-950/20'
        };
      case GameTheme.JUNGLE:
        return {
          container: 'bg-[#2a2622] border-4 border-[#5d5448] shadow-2xl font-[Cinzel]',
          title: 'text-amber-500 font-bold border-b-2 border-[#5d5448] pb-2',
          text: 'text-[#d6cbb8]',
          input: 'bg-[#1c1916] border-2 border-[#5d5448] text-[#e8e0d5] focus:border-amber-600 placeholder-[#5d5448]',
          overlay: 'backdrop-blur-sm bg-black/60'
        };
      case GameTheme.VICTORIAN:
      default:
        return {
          container: 'bg-[#1a1616] border-double border-4 border-amber-800 shadow-[0_0_60px_rgba(0,0,0,0.8)] font-serif',
          title: 'text-amber-100 italic border-b border-amber-900/50 pb-2 font-bold',
          text: 'text-amber-100/90',
          input: 'bg-black border-b border-amber-800 text-amber-100 focus:border-amber-500 placeholder-amber-900/50',
          overlay: 'backdrop-blur-sm bg-black/80'
        };
    }
  };

  const ts = getThemeStyles();

  return (
    <div className={`fixed inset-0 z-50 flex items-center justify-center p-4 animate-in fade-in duration-300 ${ts.overlay}`}>
      <div className={`relative w-full max-w-lg p-8 transform transition-all scale-100 ${ts.container}`}>
        
        {/* Decorative elements based on theme */}
        {theme === GameTheme.SPACE && (
          <div className="absolute top-2 right-2 text-[10px] text-cyan-700 animate-pulse">SECURE_CONNECTION_ESTABLISHED</div>
        )}
        
        <h2 className={`text-2xl mb-6 ${ts.title}`}>
          {puzzle.type === 'CODE' ? (theme === 'SPACE' ? 'SECURITY OVERRIDE' : 'LOCKED MECHANISM') : 'PUZZLE'}
        </h2>
        
        <div className="mb-8 p-4 bg-black/20 rounded">
          <p className={`text-lg italic leading-relaxed ${ts.text}`}>
            "{puzzle.question}"
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
             <input
              type={puzzle.type === 'CODE' ? 'number' : 'text'}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              className={`w-full p-4 text-lg outline-none transition-all ${ts.input}`}
              placeholder={theme === GameTheme.SPACE ? "ENTER_KEY_FRAGMENT..." : "Write your answer..."}
              autoFocus
              autoComplete="off"
            />
          </div>
          
          {feedback && (
            <div className={`p-3 text-center text-sm font-bold animate-pulse ${feedback.includes('Correct') || feedback.includes('Access') || feedback.includes('Verified') ? 'text-green-500' : 'text-red-500'}`}>
              [{feedback}]
            </div>
          )}

          <div className="flex justify-end gap-4 pt-4 border-t border-white/5">
            <Button theme={theme} type="button" onClick={onClose} variant="secondary">
              Close
            </Button>
            <Button theme={theme} type="submit" disabled={loading}>
              {loading ? 'Thinking...' : 'Submit Answer'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default PuzzleModal;